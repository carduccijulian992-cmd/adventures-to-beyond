import pygame
import random
import os
import sys
import asyncio
import json

pygame.init()
pygame.font.init()

SAVE_FILE = "soul_save_data.txt"

player_progression = {
    "xp": 0,
    "p1_n1": 0, "p1_n2": 0, "p1_n3": 0, "p1_n4": 0, "p1_n5": 0, "p1_n6": 0,
    "p2_n1": 0, "p2_n2": 0, "p2_n3": 0, "p2_n4": 0, "p2_n5": 0, "p2_n6": 0,
    "p3_n1": 0, "p3_n2": 0, "p3_n3": 0, "p3_n4": 0, "p3_n5": 0, "p3_n6": 0,
    "p4_n1": 0, "p4_n2": 0, "p4_n3": 0, "p4_n4": 0, "p4_n5": 0, "p4_n6": 0,
    "p5_n1": 0, "p5_n2": 0, "p5_n3": 0, "p5_n4": 0, "p5_n5": 0, "p5_n6": 0,
    "p6_n1": 0, "p6_n2": 0, "p6_n3": 0, "p6_n4": 0, "p6_n5": 0, "p6_n6": 0,
}

save_status_text = ""
status_timer = 0

def generate_save_password():
    try:
        keys_order = sorted(player_progression.keys())
        values = [str(player_progression[k]) for k in keys_order]
        raw_string = "-".join(values)
        scrambled = ""
        for char in raw_string:
            if char.isdigit():
                scrambled += str((int(char) + 3) % 10)
            else:
                scrambled += "X"
        return scrambled
    except Exception:
        return ""

def load_save_password(password_string):
    global player_progression
    try:
        keys_order = sorted(player_progression.keys())
        unscrambled = ""
        for char in password_string:
            if char.isdigit():
                unscrambled += str((int(char) - 3) % 10)
            else:
                unscrambled += "-"
        values = unscrambled.split("-")
        if len(values) != len(keys_order):
            return False
        for i, key in enumerate(keys_order):
            player_progression[key] = int(values[i])
        return True
    except Exception:
        return False

def load_game():
    global player_progression
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, "r") as f:
                for line in f:
                    if "=" in line:
                        key, val = line.strip().split("=")
                        if key in player_progression:
                            player_progression[key] = int(val)
        except Exception:
            pass

def save_game():
    try:
        with open(SAVE_FILE, "w") as f:
            for key, val in player_progression.items():
                f.write(f"{key}={val}\n")
    except Exception:
        pass

load_game()
pygame.init()
screen = pygame.display.set_mode((800, 800))
pygame.display.set_caption("adventures to beyond")
if sys.platform != "emscripten":
    pygame.scrap.init()

game_state = "title"
xp = player_progression["xp"]
gold = 0
dmg = 0
turn_state = "player"
enemy_turn_start_time = 0
player_max_hp = 100
player_max_hp_bonus_1 = 0
player_max_hp_bonus_2 = 0
player_hp = player_max_hp
last_damage_dealt = 0
enemy_damage_done = 0
shop_bonus_damage = 1
show_shop_bonus_dmg = 20
mana = 15
max_mana = 50
mana_regen = 5
magic_game_active = False
magic_path_selected = 0
magic_timer_start = 0
min_heal = 7
max_heal = 22
tree_bonus_damage = 1
tree_heal_bonus_stack = 0
tree_heal_bonus_stack_max = 0
tree_heal_dmg_bonus = 1
bonus_heal = 1
shop_bonus_crit_chance = 0
tree_bonus_crit_chance = 0
crit_chance_amount = 50
bonus_gold = 0
gold_scale_mult = 1
gold_interest = 0
wheel_dmg_bonus = 1
wheel_gold_bonus = 0
last_heal_amount = 0
hp_boost_price = 15
full_heal_price = 5
dmg_boost_price = 15
potions_boost_price = 15
bonus_crit_chance_price = 15
gold_bonus_price = 15
gold_convert = 0
spike_shield = 0
dmg_heal = 0
tree_gold_mult_1 = 1
orc_number = 1
enemy_max_hp = 40 + (orc_number * 20)
enemy_hp = enemy_max_hp
enemy_attack_power = 2 + (orc_number * 3)
enemy_stunned = False
enemy_x = 605
enemy_y = 80
enemy_state = "battle"
enemy_alpha = 255
total = 0
d1 = 0
d2 = 0
damage_taken = 0
enemy_has_shield = False

battle_log = f"an angry orc blocks your path"
magic_success = False
magic_time_limit = 4500
spell_damage = 20
magic_timer_started = False
trace_points = []
player_path = []
is_tracing = False

attack_btn = pygame.Rect(50, 700, 200, 60)
heavy_btn = pygame.Rect(300, 700, 200, 60)
heal_btn = pygame.Rect(550, 700, 200, 60)
magic_btn = pygame.Rect(550, 600, 200, 60)
start_btn = pygame.Rect(300, 400, 200, 60)
shop_btn = pygame.Rect(40, 30, 100, 40)
buy_hp_btn = pygame.Rect(30, 250, 200, 60)
buy_heal_btn = pygame.Rect(300, 250, 200, 60)
buy_attack_btn = pygame.Rect(570, 250, 200, 60)
buy_heal_bonus_btn = pygame.Rect(30, 450, 200, 60)
buy_crit_chance_bonus_btn = pygame.Rect(300, 450, 200, 60)
buy_bonus_gold_btn = pygame.Rect(570, 450, 200, 60)
leave_shop_btn = pygame.Rect(300, 700, 200, 60)
skill_tree_btn = pygame.Rect(300, 490, 200, 60)
bought_discount_max_hp = False
bought_discount_full_heal = False
bought_discount_dmg = False
bought_discount_potions = False
bought_discount_crit_chance = False
bought_discount_gold_bonus = False
back_rect = pygame.Rect(300, 730, 200, 60)
reset_skill_tree_btn = pygame.Rect(600, 740, 110, 40)
casino_btn = pygame.Rect(155, 30, 100, 40)
leave_casino_btn = pygame.Rect(300, 700, 200, 60)
flip_coin_btn = pygame.Rect(100, 300, 160, 50)
bet_5_btn = pygame.Rect(30, 400, 60, 40)
bet_15_btn = pygame.Rect(105, 400, 60, 40)
bet_25_btn = pygame.Rect(180, 400, 60, 40)
bet_50_btn = pygame.Rect(255, 400, 60, 40)
spin_wheel_btn = pygame.Rect(325, 300, 160, 50)
reaper_dice_roll_btn = pygame.Rect(550, 300, 160, 50)
casino_log = "Welcome to the Casino. Choose a game"
selected_bet = 5

PATH_X_COORDS = {"p1": 50, "p2": 170, "p3": 290, "p4": 410, "p5": 530, "p6": 650}
TIER_Y_COORDS = {1: 520, 2: 440, 3: 360, 4: 280, 5: 200, 6: 120}

SKILL_NAMES = {
    "p1_n1": "Endure Soul", "p1_n2": "Inv. Health", "p1_n3": "Iron Ward", "p1_n4": "Sec. Wind", "p1_n5": "Spike Armor", "p1_n6": "Colossus",
    "p2_n1": "Sharp Edge",  "p2_n2": "Eagle Eye",   "p2_n3": "Concussive", "p2_n4": "Merch. Cont", "p2_n5": "Vamp Blade",  "p2_n6": "Guillotine",
    "p3_n1": "Sooth Vapor", "p3_n2": "Adren Rush", "p3_n3": "Apoth. Cont",  "p3_n4": "Overheal", "p3_n5": "Quick Swig", "p3_n6": "Corr Splash",
    "p4_n1": "Trust Fund",  "p4_n2": "Merch Favor", "p4_n3": "Lucky Find",  "p4_n4": "Comp Inter", "p4_n5": "Gold Scale", "p4_n6": "Midas Touch",
    "p5_n1": "Myst Chan.",  "p5_n2": "Arcane Pres", "p5_n3": "Leyline Flow", "p5_n4": "Chan Focus", "p5_n5": "Siph. Arc",  "p5_n6": "Arc Overflow",
    "p6_n1": "Bounc. coin", "p6_n2": "High Roller",  "p6_n3": "Dbl down", "p6_n4": "Lucky 7 & 3", "p6_n5": "Lucky Break", "p6_n6": "open Casino"
}

game_font = pygame.font.SysFont("Ariel", 22)
log_font = pygame.font.SysFont("Ariel", 35)
enemy_surface = pygame.Surface((120, 120), pygame.SRCALPHA)
game_clock = pygame.time.Clock()

async def start_web_game():
    global running, game_state, xp, gold, dmg, turn_state, enemy_turn_start_time, player_max_hp, player_max_hp_bonus_1, player_max_hp_bonus_2, player_hp, last_damage_dealt, enemy_damage_done, shop_bonus_damage, show_shop_bonus_dmg, mana, max_mana, mana_regen, magic_game_active, magic_path_selected, magic_timer_start, min_heal, max_heal, tree_bonus_damage, tree_heal_bonus_stack, tree_heal_bonus_stack_max, tree_heal_dmg_bonus, bonus_heal, shop_bonus_crit_chance, tree_bonus_crit_chance, bonus_gold, gold_scale_mult, gold_interest, wheel_dmg_bonus, wheel_gold_bonus, last_heal_amount, hp_boost_price, full_heal_price, dmg_boost_price, potions_boost_price, bonus_crit_chance_price, gold_bonus_price, gold_convert, spike_shield, dmg_heal, tree_gold_mult_1, orc_number, enemy_max_hp, enemy_hp, enemy_attack_power, enemy_stunned, enemy_x, enemy_y, enemy_state, enemy_alpha, total, d1, d2, damage_taken, enemy_has_shield, battle_log, magic_success, magic_time_limit, spell_damage, magic_timer_started, trace_points, player_path, is_tracing, status_timer, save_status_text

    running = True
    while running:
        current_time = pygame.time.get_ticks()
        mouse_pos = pygame.mouse.get_pos()
        mx, my = mouse_pos
        clicked = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                clicked = True

        if game_state == "title":
            screen.fill((90, 90, 115))
            title_surface = log_font.render("adventures to beyond", True, (255, 215, 0))
            screen.blit(title_surface, (272, 150))

            pygame.draw.rect(screen, (70, 70, 80), start_btn)
            button_label = game_font.render("start game", True, (255, 255, 255))
            screen.blit(button_label, (360, 420))

            pygame.draw.rect(screen, (50, 50, 65), skill_tree_btn)
            screen.blit(game_font.render("skill tree", True, (255, 255, 255)), (370, 512))

            export_rect = pygame.Rect(50, 700, 220, 45)
            pygame.draw.rect(screen, (75, 0, 130), export_rect, border_radius=8)
            pygame.draw.rect(screen, (240, 240, 240), export_rect, 2, border_radius=8)
            export_text = game_font.render("EXPORT SAVE CODE", True, (240, 240, 240))
            screen.blit(export_text, (export_rect.x + 20, export_rect.y + 12))

            import_rect = pygame.Rect(530, 700, 220, 45)
            pygame.draw.rect(screen, (75, 0, 130), import_rect, border_radius=8)
            pygame.draw.rect(screen, (240, 240, 240), import_rect, 2, border_radius=8)
            import_text = game_font.render("IMPORT SAVE CODE", True, (240, 240, 240))
            screen.blit(import_text, (import_rect.x + 20, import_rect.y + 12))

            if status_timer > 0:
                status_render = game_font.render(save_status_text, True, (255, 215, 0))
                screen.blit(status_render, (400 - (status_render.get_width() // 2), 650))
                status_timer -= 1

            if clicked:
                if start_btn.collidepoint(mouse_pos):
                    endure_soul_lvl = player_progression.get("p1_n1", 0)
                    Colossus_lvl = player_progression.get("p1_n6", 0)
                    sec_wind_lvl = player_progression.get("p1_n4", 0)
                    trust_fund_lvl = player_progression.get("p4_n1", 0)
                    sharp_edge_lvl = player_progression.get("p2_n1", 0)
                    eagle_eye_lvl = player_progression.get("p2_n2", 0)
                    if eagle_eye_lvl == 1:
                        tree_bonus_crit_chance = 5
                    elif eagle_eye_lvl == 2:
                        tree_bonus_crit_chance = 10
                    elif eagle_eye_lvl == 3:
                        tree_bonus_crit_chance = 15
                    else:
                        tree_bonus_crit_chance = 0
                    if sharp_edge_lvl == 1:
                        tree_bonus_damage = 1.2
                    elif sharp_edge_lvl == 2:
                        tree_bonus_damage = 1.4
                    elif sharp_edge_lvl == 3:
                        tree_bonus_damage = 1.6
                    else:
                        tree_bonus_damage = 1
                    if endure_soul_lvl == 1:
                        player_max_hp_bonus_1 = 20
                    elif endure_soul_lvl == 2:
                        player_max_hp_bonus_1 = 40
                    elif endure_soul_lvl == 3:
                        player_max_hp_bonus_1 = 60
                    if Colossus_lvl == 1:
                        player_max_hp_bonus_2 = 60
                    elif Colossus_lvl == 2:
                        player_max_hp_bonus_2 = 120
                    elif Colossus_lvl == 3:
                        player_max_hp_bonus_2 = 180
                    else:
                        player_max_hp_bonus_2 = 0
                    if sec_wind_lvl == 1:
                        sec_wind_left = 1 
                    elif sec_wind_lvl == 2:
                        sec_wind_left = 1
                    elif sec_wind_lvl == 3:
                        sec_wind_left = 2
                    else:
                        sec_wind_left = 0
                    if trust_fund_lvl == 1:
                        gold = 15
                    elif trust_fund_lvl == 2:
                        gold = 30
                    elif trust_fund_lvl == 3:
                        gold = 45
                    else:
                        gold = 0
                    player_max_hp = 60 + player_max_hp_bonus_2 + player_max_hp_bonus_1
                    player_hp = player_max_hp
                    shop_bonus_damage = 1
                    show_shop_bonus_dmg = 20
                    shop_bonus_crit_chance = 0
                    crit_chance_amount = 50 + tree_bonus_crit_chance
                    bonus_heal = 1
                    orc_number = 1
                    enemy_has_shield = False
                    enemy_attack_power = 2 + (orc_number * 3)
                    enemy_max_hp = 40 + (orc_number * 20)
                    enemy_hp = enemy_max_hp
                    enemy_alpha = 255
                    enemy_state = "battle"
                    turn_state = "player"
                    enemy_x = 605
                    battle_log = f"an angry orc blocks your path"
                    myst_chan_lvl = player_progression.get("p5_n1", 0)
                    arcane_pres_lvl = player_progression.get("p5_n2", 0)
                    chan_focus_lvl = player_progression.get("p5_n4", 0)
                    if myst_chan_lvl == 1:
                        spell_damage = 20
                    elif myst_chan_lvl == 2:
                        spell_damage = 40
                    elif myst_chan_lvl == 3:
                        spell_damage = 60
                    if arcane_pres_lvl >= 1:
                        magic_time_limit = 6000
                    else:
                        magic_time_limit = 4500
                    mana = 15
                    trace_points = [
                        (180, 420),
                        (200, 400),
                        (350, 250),
                        (500, 550),
                        (650, 400),
                        (670, 380)
                    ]
                    max_mana = 50
                    hp_boost_price = 15
                    game_state = "playing"
                    clicked = False

                elif skill_tree_btn.collidepoint(mouse_pos):
                    game_state = "skill_tree"
                    clicked = False

                elif export_rect.collidepoint(mouse_pos):
                    code = generate_save_password()
                    if code:
                        if sys.platform == "emscripten":
                            from javascript import window
                            window.prompt("YOUR CHARACTER SAVE CODE (Copy this code):", code)
                        else:
                            pygame.scrap.put(pygame.SCRAP_TEXT, code.encode('utf-8'))
                            save_status_text = "SAVE CODE COPIED TO CLIPBOARD!"
                            status_timer = 120
                    clicked = False
                        
                elif import_rect.collidepoint(mouse_pos):
                    if sys.platform == "emscripten":
                        from javascript import window
                        user_code = window.prompt("PASTE YOUR CHARACTER SAVE CODE HERE:")
                        if user_code:
                            clean_code = str(user_code).strip()
                            if load_save_password(clean_code):
                                save_status_text = "SAVE LOADED SUCCESSFULLY!"
                            else:
                                save_status_text = "INVALID CODE!"
                        else:
                            save_status_text = "IMPORT CANCELED"
                        status_timer = 120
                    else:
                        clipboard_data = pygame.scrap.get(pygame.SCRAP_TEXT)
                        if clipboard_data:
                            clean_code = clipboard_data.decode('utf-8').strip().replace('\x00', '')
                            if load_save_password(clean_code):
                                save_status_text = "SAVE LOADED SUCCESSFULLY!"
                            else:
                                save_status_text = "INVALID CODE!"
                        else:
                            save_status_text = "CLIPBOARD IS EMPTY!"
                        status_timer = 120
                    clicked = False


        elif game_state == "shop":
            screen.fill((45, 30, 20))
            screen.blit(log_font.render("merchant's outpost", True, (255, 215, 0)), (250, 80))
            screen.blit(game_font.render(f"gold: {gold}", True, (255, 255, 255)), (340, 150))

            pygame.draw.rect(screen, (70, 80, 70), buy_hp_btn)
            double_down_lvl = player_progression.get("p6_n3", 0)
            shop_hp_gain = 20
            inv_health_lvl = player_progression.get("p1_n2", 0)
            if inv_health_lvl == 1:
                shop_hp_gain = 25
            elif inv_health_lvl == 2:
                shop_hp_gain = 30
            elif inv_health_lvl == 3:
                shop_hp_gain = 35

            if clicked and buy_hp_btn.collidepoint(mouse_pos):
                if gold >= hp_boost_price:
                    gold -= hp_boost_price
                    player_max_hp += shop_hp_gain
                    player_hp += shop_hp_gain
                    if hp_boost_price == 15:
                        bought_discount_max_hp = False
                    else:
                        bought_discount_max_hp = True
                    save_game()
                    if bought_discount_max_hp == False:
                        roll = random.randint(1, 100)
                        if double_down_lvl == 1 and roll <= 20:
                            hp_boost_price = 7
                        elif double_down_lvl == 2 and roll <= 30:
                            hp_boost_price = 7
                        elif double_down_lvl == 3 and roll <= 30:
                            hp_boost_price = 0
                        else:
                            hp_boost_price = 15
                    elif bought_discount_max_hp == True:
                        hp_boost_price = 15
            screen.blit(game_font.render(f"boost hp ({hp_boost_price}G)", True, (255, 255, 255)), (75, 272))
            screen.blit(game_font.render(f"+{shop_hp_gain} max hp", True, (180, 180, 180)), (80, 320))

            pygame.draw.rect(screen, (80, 70, 70), buy_heal_btn)
            if clicked and buy_heal_btn.collidepoint(mouse_pos):
                if gold >= full_heal_price:
                    gold -= full_heal_price
                    player_hp = player_max_hp
                    if full_heal_price == 5:
                        bought_discount_full_heal = False
                    else:
                        bought_discount_full_heal = True
                    save_game()
                    if bought_discount_full_heal == False:
                        roll = random.randint(1, 100)
                        if double_down_lvl == 1 and roll <= 20:
                            full_heal_price = 2
                        elif double_down_lvl == 2 and roll <= 30:
                            full_heal_price = 2
                        elif double_down_lvl == 3 and roll <= 30:
                            full_heal_price = 0
                        else:
                            full_heal_price = 5
                    elif bought_discount_full_heal == True:
                        full_heal_price = 5
            screen.blit(game_font.render(f"full heal ({full_heal_price}G)", True, (255, 255, 255)), (355, 272))
            screen.blit(game_font.render(f"restore max hp", True, (180, 180, 180)), (350, 320))

            pygame.draw.rect(screen, (100, 70, 80), buy_attack_btn)
            shop_dmg_gain = 0.2
            show_shop_bonus_dmg = 20
            merch_cont_lvl = player_progression.get("p2_n4", 0)
            if merch_cont_lvl == 1:
                shop_dmg_gain = 0.3
                show_shop_bonus_dmg = 30
            elif merch_cont_lvl == 2:
                shop_dmg_gain = 0.4
                show_shop_bonus_dmg = 40
            elif merch_cont_lvl == 3:
                shop_dmg_gain  = 0.5
                show_shop_bonus_dmg = 50
            if clicked and buy_attack_btn.collidepoint(mouse_pos):
                if gold >= dmg_boost_price:
                    gold -= dmg_boost_price
                    shop_bonus_damage += shop_dmg_gain
                    if dmg_boost_price == 15:
                        bought_discount_dmg = False
                    else:
                        bought_discount_dmg = True
                    save_game()
                    if bought_discount_dmg == False:
                        roll = random.randint(1, 100)
                        if double_down_lvl == 1 and roll <= 20:
                            dmg_boost_price = 7
                        elif double_down_lvl == 2 and roll <= 30:
                            dmg_boost_price = 7
                        elif double_down_lvl == 3 and roll <= 30:
                            dmg_boost_price = 0
                        else:
                            dmg_boost_price = 15
                    elif bought_discount_dmg == True:
                        dmg_boost_price = 15
            screen.blit(game_font.render(f"boost damage ({dmg_boost_price}G)", True, (255, 255, 255)), (595, 272))
            screen.blit(game_font.render(f"+{show_shop_bonus_dmg}% more damage", True, (180, 180, 180)), (605, 320))

            pygame.draw.rect(screen, (80, 100, 80), buy_heal_bonus_btn)
            shop_heal_gain = 0.2
            show_bonus_heal = 20
            apoth_cont_lvl = player_progression.get("p3_n3", 0)
            if apoth_cont_lvl == 1:
                shop_heal_gain = 0.3
                show_bonus_heal = 30
            elif apoth_cont_lvl == 2:
                shop_heal_gain = 0.4
                show_bonus_heal = 40
            elif apoth_cont_lvl == 3:
                shop_heal_gain = 0.5
                show_bonus_heal = 50
            if clicked and buy_heal_bonus_btn.collidepoint(mouse_pos):
                if gold >= potions_boost_price:
                    gold -= potions_boost_price
                    bonus_heal += shop_heal_gain
                    if potions_boost_price == 15:
                        bought_discount_potions = False
                    else:
                        bought_discount_potions = True
                    save_game()
                    if bought_discount_potions == False:
                        roll = random.randint(1, 100)
                        if double_down_lvl == 1 and roll <= 20:
                            potions_boost_price = 7
                        elif double_down_lvl == 2 and roll <= 30:
                            potions_boost_price = 7
                        elif double_down_lvl == 3 and roll <= 30:
                            potions_boost_price = 0
                        else:
                            potions_boost_price = 15
                    elif bought_discount_potions == True:
                        potions_boost_price = 15
            screen.blit(game_font.render(f"boost potions ({potions_boost_price}G)", True, (255, 255, 255)), (60, 472))
            screen.blit(game_font.render(f"+{show_bonus_heal}% more healing", True, (180, 180, 180)), (65, 520))

            pygame.draw.rect(screen, (70, 70, 100), buy_crit_chance_bonus_btn)
            if clicked and buy_crit_chance_bonus_btn.collidepoint(mouse_pos):
                if gold >= bonus_crit_chance_price:
                    gold -= bonus_crit_chance_price
                    shop_bonus_crit_chance += 5
                    crit_chance_amount += 5
                    if bonus_crit_chance_price == 15:
                        bought_discount_crit_chance = False
                    else:
                        bought_discount_crit_chance = True
                    save_game()
                    if bought_discount_crit_chance == False:
                        roll = random.randint(1, 100)
                        if double_down_lvl == 1 and roll <= 20:
                            bonus_crit_chance_price = 7
                        elif double_down_lvl == 2 and roll <= 30:
                            bonus_crit_chance_price = 7
                        elif double_down_lvl == 3 and roll <= 30:
                            bonus_crit_chance_price = 0
                        else:
                            bonus_crit_chance_price = 15
                    elif bought_discount_crit_chance == True:
                        bonus_crit_chance_price = 15
            screen.blit(game_font.render(f"boost accuracy ({bonus_crit_chance_price}G)", True, (255, 255, 255)), (325, 472))
            screen.blit(game_font.render(f"+5% more crit chance", True, (180, 180, 180)), (325, 520))
            screen.blit(game_font.render(f"(you have a {crit_chance_amount}% crit chance)", True, (180, 180, 180)), (300, 540))

            pygame.draw.rect(screen, (110, 90, 70), buy_bonus_gold_btn)
            if clicked and buy_bonus_gold_btn.collidepoint(mouse_pos):
                if gold >= gold_bonus_price:
                    gold -= gold_bonus_price
                    bonus_gold += 5
                    if gold_bonus_price == 15:
                        bought_discount_gold_bonus = False
                    else:
                        bought_discount_gold_bonus = True
                    save_game()
                    if bought_discount_gold_bonus == False:
                        roll = random.randint(1, 100)
                        if double_down_lvl == 1 and roll <= 20:
                            gold_bonus_price = 7
                        elif double_down_lvl == 2 and roll <= 30:
                            gold_bonus_price = 7
                        elif double_down_lvl == 3 and roll <= 30:
                            gold_bonus_price = 0
                        else:
                            gold_bonus_price = 15
                    elif bought_discount_gold_bonus == True:
                        gold_bonus_price = 15
            screen.blit(game_font.render(f"boost orc kills ({gold_bonus_price}G)", True, (255, 255, 255)), (600, 472))
            screen.blit(game_font.render(f"+5 more gold/kill", True, (180, 180, 180)), (620, 520))

            pygame.draw.rect(screen, (100, 100, 110), leave_shop_btn)
            screen.blit(game_font.render("leave shop", True, (255, 255, 255)), (360, 722))
            if clicked and leave_shop_btn.collidepoint(mouse_pos):
                game_state = "playing"
                clicked = False

        elif game_state == "casino":
            screen.fill((40, 15, 30))
            screen.blit(log_font.render("The Golden Orc Casino", True, (255, 215, 0)), (265, 60))
            screen.blit(game_font.render(f"Gold: {gold}  |  Max HP: {player_max_hp}", True, (255, 255, 255)), (320, 130))
            open_casino_lvl = player_progression.get("p6_n6", 0)

            if player_hp >= 1:
                if open_casino_lvl >= 1:
                    pygame.draw.rect(screen, (50, 70, 110), flip_coin_btn, border_radius=4)
                    screen.blit(game_font.render("Flip Coin", True, (255, 255, 255)), (147, 315))
                    for b_btn, amt in [(bet_5_btn, 5), (bet_15_btn, 15), (bet_25_btn, 25), (bet_50_btn, 50)]:
                        btn_color = (200, 160, 40) if selected_bet == amt else (70, 70, 80)
                        pygame.draw.rect(screen, btn_color, b_btn, border_radius=4)
                        screen.blit(game_font.render(f"{amt}G", True, (255, 255, 255)), (b_btn.x + 15, b_btn.y + 10))
                        if clicked and b_btn.collidepoint(mouse_pos):
                            selected_bet = amt
                            clicked = False
                    if clicked and flip_coin_btn.collidepoint(mouse_pos):
                        if "casino_wind_log" in locals():
                            del casino_wind_log
                        if gold >= selected_bet:
                            gold -= selected_bet
                            if random.choice([True, False]):
                                gold += selected_bet * 2
                                casino_log = f"Heads! You won {selected_bet * 2} Gold"
                            else:
                                casino_log = "Tails! You lost your bet"
                            save_game()
                        else:
                            casino_log = "Not enough gold to place that bet"
                        clicked = False

                if open_casino_lvl >= 2:
                    pygame.draw.rect(screen, (110, 50, 70), spin_wheel_btn, border_radius=4)
                    screen.blit(game_font.render("Spin Wheel (10G)", True, (255, 255, 255)), (346, 315))
                    if clicked and spin_wheel_btn.collidepoint(mouse_pos):
                        if "casino_wind_log" in locals():
                            del casino_wind_log
                        if gold >= 10:
                            gold -= 10
                            roll = random.randint(1, 100)
                            if roll <= 40:
                                damage_taken = 15
                                player_hp = player_hp - damage_taken
                                casino_log = f"Whammy! The wheel zapped you for {damage_taken} hp"
                            elif roll <= 55 and roll > 40:
                                shop_bonus_damage += 0.1
                                casino_log = "Jackpot! +10% Damage for the rest of the run"
                            elif roll <= 70 and roll > 55:
                                bonus_heal += 0.1
                                casino_log = "Jackpot! +10% Potion Healing for the rest of the run"
                            elif roll <= 80 and roll > 70:
                                casino_log = "whammy! nothing happens"
                            else:
                                gold += 25
                                casino_log = "Jackpot! You won 25 Gold"
                            save_game()
                        else:
                            casino_log = "Spinning costs 10 Gold"
                        clicked = False

                if open_casino_lvl >= 3:
                    pygame.draw.rect(screen, (40, 40, 45), reaper_dice_roll_btn, border_radius=4)
                    screen.blit(game_font.render("Roll Dice (10 max hp)", True, (255, 255, 255)), (555, 315))
                    if clicked and reaper_dice_roll_btn.collidepoint(mouse_pos):
                        if "casino_wind_log" in locals():
                            del casino_wind_log
                        if player_max_hp > 15:
                            d1 = random.randint(1, 6)
                            d2 = random.randint(1, 6)
                            total = d1 + d2
                            if total == 7 or total == 11:
                                gold += 20
                                casino_log = f"Rolled {total}! The reaper spares your hp and gives 20G"
                            elif d1 == d2:
                                player_max_hp -= 15
                                if player_hp > player_max_hp: player_hp = player_max_hp
                                gold += 10
                                casino_log = f"Doubles ({d1}s)! Lost 15 max hp, but won 10G consolation"
                            else:
                                player_max_hp -= 15
                                if player_hp > player_max_hp:
                                    player_hp = player_max_hp
                                casino_log = f"Rolled {total}. The reaper claims 15 max hp. No reward"
                            save_game()
                        else:
                            casino_log = "Your soul is too weak to bet any more max hp"
                        clicked = False

            if player_hp < 1:
                sec_wind_lvl = player_progression.get("p1_n4", 0)
                if sec_wind_left > 0:
                    if sec_wind_lvl == 1:
                        player_hp = 40
                        sec_wind_left -= 1
                        casino_wind_log = "You died and second wind ability was activated"
                    elif sec_wind_lvl == 2 or sec_wind_lvl == 3:
                        player_hp = 40 + int(player_max_hp * 0.3)
                        sec_wind_left -= 1
                        casino_wind_log = "You died and second wind ability was activated"
                else:
                    game_state = "title"
                    clicked = False
            if game_state == "casino":
                pygame.draw.rect(screen, (100, 100, 110), leave_casino_btn, border_radius=4)
                screen.blit(game_font.render("Leave Casino", True, (255, 255, 255)), (353, 722))
                if clicked and leave_casino_btn.collidepoint(mouse_pos):
                    game_state = "playing"
                    casino_log = "Welcome to the Casino. Choose a game"
                    if "casino_wind_log" in locals():
                        del casino_wind_log
                    clicked = False

            if casino_log == "Welcome to the Casino. Choose a game":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (255, 200))
            elif casino_log == "Your soul is too weak to bet any more max hp":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (240, 200))
            elif casino_log == f"Rolled {total}. The reaper claims 15 max hp. No reward":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (220, 200))
            elif casino_log == f"Doubles ({d1}s)! Lost 15 max hp, but won 10G consolation":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (200, 200))
            elif casino_log == f"Rolled {total}! The reaper spares your hp and gives 20G":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (210, 200))
            elif casino_log == "Spinning costs 10 Gold":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (310, 200))
            elif casino_log == "Jackpot! You won 25 Gold":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (305, 200))
            elif casino_log == "whammy! nothing happens":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (300, 200))
            elif casino_log == "Jackpot! +10% Potion Healing for the rest of the run":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (220, 200))
            elif casino_log == "Jackpot! +10% Damage for the rest of the run":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (240, 200))
            elif casino_log == f"Whammy! The wheel zapped you for {damage_taken} hp":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (245, 200))
            elif casino_log == "Not enough gold to place that bet":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (275, 200))
            elif casino_log == "Tails! You lost your bet":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (320, 200))
            elif casino_log == f"Heads! You won {selected_bet * 2} Gold":
                screen.blit(game_font.render(casino_log, True, (240, 220, 150)), (310, 200))
            if "casino_wind_log" in locals() and casino_wind_log == "You died and second wind ability was activated":
                screen.blit(game_font.render(casino_wind_log, True, (240, 220, 150)), (240, 230))

        elif game_state == "skill_tree":
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_q] and keys[pygame.K_w] and keys[pygame.K_e] and keys[pygame.K_r] and keys[pygame.K_t] and keys[pygame.K_y]):
                player_progression["xp"] = 10000
            if (keys[pygame.K_i] and keys[pygame.K_o] and keys[pygame.K_p]):
                player_progression["xp"] += 1
                save_game()
            screen.fill((25, 20, 35))
            screen.blit(log_font.render("SOUL RECONQUER: SKILL TREE", True, (218, 112, 214)), (180, 40))
            screen.blit(game_font.render(f"Permanent XP: {player_progression['xp']}", True, (255, 255, 255)), (320, 95))
            screen.blit(log_font.render("Tank", True, (30, 150, 30)), (70, 590))
            screen.blit(log_font.render("Damage", True, (190, 20, 20)), (170, 590))
            screen.blit(log_font.render("Potions", True, (80, 200, 40)), (292, 590))
            screen.blit(log_font.render("Gold", True, (240, 210, 30)), (430, 590))
            screen.blit(log_font.render("Magic", True, (70, 25, 170)), (545, 590))
            screen.blit(log_font.render("Gambler", True, (240, 240, 240)), (650, 590))
            hovered_node = None

            pygame.draw.rect(screen, (150, 50, 50), reset_skill_tree_btn)
            screen.blit(game_font.render("reset skills", True, (255, 255, 255)), (615, 753))
            if clicked and reset_skill_tree_btn.collidepoint(mouse_pos):
                for key in player_progression:
                    if key != "xp":
                        player_progression[key] = 0
                save_game()
                clicked = False

            for path in ["p1", "p2", "p3", "p4", "p5", "p6"]:
                x = PATH_X_COORDS[path]
                for tier in range(1, 7):
                    y = TIER_Y_COORDS[tier]
                    node_key = f"{path}_n{tier}"
                    current_level = player_progression[node_key]
                    is_unlocked = True
                    if tier > 1:
                        is_unlocked = player_progression[f"{path}_n{tier-1}"] > 0
                    if current_level == 3:
                        node_color = (0, 180, 100)
                    elif is_unlocked:
                        node_color = (100, 80, 120)
                    else:
                        node_color = (45, 40, 50)
                    node_rect = pygame.Rect(x, y, 100, 55)
                    pygame.draw.rect(screen, node_color, node_rect, border_radius=6)
                    name_text = game_font.render(SKILL_NAMES[node_key], True, (255, 255, 255) if is_unlocked else (120, 120, 120))
                    level_text = game_font.render(f"{current_level}/3", True, (255, 215, 0) if current_level > 0 else (160, 160, 160))
                    screen.blit(name_text, (x + 6, y + 8))
                    screen.blit(level_text, (x + 35, y + 32))
                    if node_rect.collidepoint(mouse_pos):
                        hovered_node = node_key

                    if clicked and node_rect.collidepoint(mouse_pos) and is_unlocked and current_level < 3:
                        next_level = current_level + 1
                        base_increase = (tier - 1) * 5
                        if next_level == 1:
                            next_cost = 15 + base_increase
                        elif next_level == 2:
                            next_cost = 35 + base_increase
                        elif next_level == 3:
                            next_cost = 65 + base_increase
                        if player_progression["xp"] >= next_cost:
                            player_progression["xp"] -= next_cost
                            player_progression[node_key] += 1
                            save_game()

            SKILL_DESC = {
                "p1_n1": [
                    "lvl 1 - +20 starting max hp",
                    "",
                    "lvl 2 - +40 starting max hp",
                    "",
                    "lvl 3 - +60 starting max hp"
                ],
                "p1_n2": [
                    "lvl 1 - The shop max hp upgrade",
                    "gives +25 max hp instead of +20",
                    "lvl 2 - Shop max hp gives +30",
                    "",
                    "lvl 3 - Shop max hp gives +35"
                ],
                "p1_n3": [
                    "lvl 1 - Block 10% of incoming dmg",
                    "",
                    "lvl 2 - Block 20% of dmg",
                    "",
                    "lvl 3 - Block 30% of dmg"
                ],
                "p1_n4": [
                    "lvl 1 - Revive once after death with",
                    "40 hp",
                    "lvl 2 - Revive with 40 hp + 30% of",
                    "max hp",
                    "lvl 3 - Revive twice per run"
                ],
                "p1_n5": [
                    "lvl 1 - 10% of dmg taken is done to",
                    "the enemy",
                    "lvl 2 - Reflect 20% dmg",
                    "",
                    "lvl 3 - Reflect 30% dmg"
                ],
                "p1_n6": [
                    "lvl 1 - +60 starting max HP",
                    "",
                    "lvl 2 - +120 starting max HP",
                    "",
                    "lvl 3 - +180 starting max HP"
                ],
                "p2_n1": [
                    "lvl 1 - +20% base damage",
                    "",
                    "lvl 2 - +40% base damage",
                    "",
                    "lvl 3 - +60% base damage"
                ],
                "p2_n2": [
                    "lvl 1 - 5% more Crit Rate",
                    "",
                    "lvl 2 - 10% more Crit Rate",
                    "",
                    "lvl 3 - 15% more Crit Rate"
                ],
                "p2_n3": [
                    "lvl 1 - 5% chance to stun the orc",
                    "when dealing damage",
                    "lvl 2 - 10% Stun Chance",
                    "",
                    "lvl 3 - 15% Stun Chance"
                ],
                "p2_n4": [
                    "lvl 1 - The shop dmg upgrade gives",
                    "+30% dmg instead of +20%",
                    "lvl 2 - Shop Dmg +40%",
                    "",
                    "lvl 3 - Shop Dmg +50%"
                ],
                "p2_n5": [
                    "lvl 1 - Heal for 15% of damage dealt",
                    "",
                    "lvl 2 - 20% Lifesteal",
                    "",
                    "lvl 3 - 25% Lifesteal"
                ],
                "p2_n6": [
                    "lvl 1 - instantly kill any enemy",
                    "below 6% hp",
                    "lvl 2 - instantly kill any enemy",
                    "below 12% hp",
                    "lvl 3 - instantly kill any enemy",
                    "below 20% hp"
                ],
                "p3_n1": [
                    "lvl 1 - The min and max heal for the",
                    "heal btn is raised by 5",
                    "lvl 2 - min and max heal is raised",
                    "by 10",
                    "lvl 3 - min and max heal is raised",
                    "by 15"
                ],
                "p3_n2": [
                    "lvl 1 - dmg is increased by 10% on",
                    "your next turn after healing(doesn't stack)",
                    "lvl 2 - next dmg dealt is increased",
                    "by 20%",
                    "lvl 3 - Stacks up to two times"
                ],
                "p3_n3": [
                    "lvl 1 - The shop potions upgrade",
                    "gives +30% instead of 20%",
                    "lvl 2 - Shop potions gives +40%",
                    "",
                    "lvl 3 - Shop potions gives +50%"
                ],
                "p3_n4": [
                    "lvl 1 - if healing goes over max hp,",
                    " 60% is added (overheal)",
                    "lvl 2 - Overheal 75% of healing done",
                    "lvl 3 - Overheal 100% of healing done"
                ],
                "p3_n5": [
                    "lvl 1 - 10% chance to heal without",
                    "using up a turn",
                    "lvl 2 - 20% for a quick swig",
                    "",
                    "lvl 3 - 30% for a quick swig"
                ],
                "p3_n6": [
                    "lvl 1 - drinking a potion deals 15%",
                    "of healing done as dmg",
                    "lvl 2 - damages for 25% healing",
                    "",
                    "lvl 3 - damages for 35% healing"
                ],
		        "p4_n1": [
                    "lvl 1 - +15 Starting Gold",
                    "",
                    "lvl 2 - +30 Starting Gold",
                    "",
                    "lvl 3 - +45 Starting Gold"
                ],
                "p4_n2": [
                    "lvl 1 - 25% chance for a free upgrade",
                    "in the shop after defeating an enemy",
                    "lvl 2 - 50% chance for a free Item",
                    "",
                    "lvl 3 - 75% chance for a free Item"
                ],
                "p4_n3": [
                    "lvl 1 - 10% chance to gain double",
                    "the gold for a kill",
                    "lvl 2 - 20% chance for double gold",
                    "",
                    "lvl 3 - 30% chance for double gold"
                ],
                "p4_n4": [
                    "lvl 1 - +5% of your gold after you",
                    "kill an orc",
                    "lvl 2 - +10% Interest",
                    "",
                    "lvl 3 - +15% Interest"
                ],
                "p4_n5": [
                    "lvl 1 - +2% Dmg for every 20 gold",
                    "you have (max +50%)",
                    "lvl 2 - +4% Dmg for every 20 gold",
                    "(max +50%)",
                    "lvl 3 - +6% Dmg for every 20 gold",
                    "(max +50%)"
                ],
                "p4_n6": [
                    "lvl 1 - 5% of damage dealt converts",
                    "to gold",
                    "lvl 2 - Convert 10% Dmg",
                    "",
                    "lvl 3 - Convert 15% Dmg"
                ],
		        "p5_n1": [
                    "lvl 1 - gain a new btn, complete a",
                    "spell to do 20 unblockable dmg",
                    "(spells cost 15 mana to cast, +5/turn)",
                    "lvl 2 - 40 Magic Dmg",
                    "lvl 3 - 60 Magic Dmg"
                ],
                "p5_n2": [
                    "lvl 1 - +1.5s added to the timer",
                    "",
                    "lvl 2 - line width shrinks",
                    "",
                    "lvl 3 - Instantly cast, no spell",
                    "completing needed"
                ],
                "p5_n3": [
                    "lvl 1 - +6 Mana/Turn instead of +5",
                    "",
                    "lvl 2 - +7 Mana/Turn",
                    "",
                    "lvl 3 - if you dont have enough mana,",
                    "use hp at a 2:1 ratio (2 hp for 1 mana)"
                ],
                "p5_n4": [
                    "lvl 1 - spells cost 2 less mana",
                    "",
                    "lvl 2 - spells cost 4 less mana",
                    "",
                    "lvl 3 - 15% chance for mana cost to",
                    "be refunded"
                ],
                "p5_n5": [
                    "lvl 1 - you gain mana equal to 15%",
                    "of damage dealt",
                    "lvl 2 - you gain mana equal to 30%",
                    "of damage dealt",
                    "lvl 3 - you gain mana equal to 45%",
                    "of damage dealt",
                ],
                "p5_n6": [
                    "lvl 1 - +10% magic dmg if your",
                    "mana bar is full",
                    "lvl 2 - +20% magic dmg if your",
                    "manabar is full",
                    "lvl 3 - +30% magic dmg if your",
                    "mana bar is full"
                ],
		        "p6_n1": [
                    "lvl 1 - 10% chance to get 2x gold",
                    "when killing an orc",
                    "lvl 2 - 20% chance for 2x gold",
                    "",
                    "lvl 3 - 20% chance for 3x gold"
                ],
                "p6_n2": [
                    "lvl 1 - 10% to deal 1.5x dmg",
                    "",
                    "lvl 2 - 20% chance to deal 1.5x dmg",
                    "",
                    "lvl 3 - 20% chance to deal 2x damage"
                ],
                "p6_n3": [
                    "lvl 1 - after buying a shop ugrade,",
                    "20% chance for it to be 50% off",
                    "lvl 2 - 30% chance for 50% off",
                    "",
                    "lvl 3 - 30% chance for the upgrade",
                    "to be free"
                ],
                "p6_n4": [
                    "lvl 1 - if your gold ends in a 7 or 3",
                    "1.2x dmg and 10% more crit chance",
                    "lvl 2 - 1.4x dmg and 10% more",
                    "crit chance",
                    "lvl 3 - 1.6x dmg and 20% more",
                    "crit chance"
                ],
                "p6_n5": [
                    "lvl 1 - 5% chance to dodge the orc",
                    "",
                    "lvl 2 - 12% dodge chance",
                    "",
                    "lvl 3 - 20% dodge chance"
                ],
                "p6_n6": [
                    "lvl 1 - before a battle spin a wheel",
                    "70% whammy, 15% for 1.3x dmg or +10 gold",
                    "lvl 2 - 60% whammy, 15% for",
                    "1.3x dmg or +15 gold",
                    "lvl 3 - 50% whammy, 20% for 1.3x dmg",
                    "or +15 gold, 10% chance for both"
                ]
            }

            if hovered_node and hovered_node in SKILL_DESC:
                card_x, card_y = mx + 15, my + 15
                if card_x > 405: card_x = mx - 270
                card_rect = pygame.Rect(card_x, card_y, 270, 150)
                pygame.draw.rect(screen, (40, 35, 45), card_rect, border_radius=5)
                pygame.draw.rect(screen, (218, 112, 214), card_rect, width=1, border_radius=5)

                for index, desc_line in enumerate(SKILL_DESC[hovered_node]):
                    screen.blit(game_font.render(desc_line, True, (240, 240, 245)), (card_x + 10, card_y + 8 + (index * 19)))

                if hovered_node in player_progression:
                    lvl = player_progression[hovered_node]
                    if lvl == 3:
                        cost_string, cost_color = "MAX LEVEL REACHED", (0, 255, 150)
                    else:
                        hovered_tier = int(hovered_node.split("_n")[1])
                        base_increase = (hovered_tier - 1) * 5
                        next_lvl = lvl + 1

                        if next_lvl == 1:
                            next_lvl_xp_price = 15 + base_increase
                        elif next_lvl == 2:
                            next_lvl_xp_price = 35 + base_increase
                        elif next_lvl == 3:
                            next_lvl_xp_price = 65 + base_increase

                        cost_string = f"Next Level Cost: {next_lvl_xp_price} XP"
                        cost_color = (255, 215, 0) if player_progression["xp"] >= next_lvl_xp_price else (255, 100, 100)

                    screen.blit(game_font.render(cost_string, True, cost_color), (card_x + 10, card_y + 125))

            pygame.draw.rect(screen, (70, 60, 80), back_rect, border_radius=4)
            screen.blit(game_font.render("BACK TO MENU", True, (255, 255, 255)), (340, 752))
            if clicked and back_rect.collidepoint(mouse_pos):
                xp = player_progression["xp"]
                game_state = "title"

        elif game_state == "magic_minigame":
            screen.fill((15, 10, 25))
            if not magic_timer_started:
                time_remaining = magic_time_limit
            else:
                time_elapsed = pygame.time.get_ticks() - magic_timer_start
                time_remaining = max(0, magic_time_limit - time_elapsed)
            arcane_pres_lvl = player_progression.get("p5_n2", 0)
            myst_chan_lvl = player_progression.get("p5_n1", 0)
            siph_arc_lvl = player_progression.get("p5_n5", 0)
            arc_overflow_lvl = player_progression.get("p5_n6", 0)
            tunnel_width = 20 
            if arcane_pres_lvl == 0:
                brush_size = 12
            elif arcane_pres_lvl == 1:
                brush_size = 12
            elif arcane_pres_lvl >= 2:
                brush_size = 8

            if len(trace_points) >= 2:
                pygame.draw.lines(screen, (50, 50, 55), False, trace_points, width=tunnel_width)
                for pt in trace_points:
                    pygame.draw.circle(screen, (50, 50, 55), pt, tunnel_width // 2)
            if trace_points:
                pygame.draw.circle(screen, (40, 180, 100), trace_points[1], 12) 
                pygame.draw.circle(screen, (180, 40, 60), trace_points[-2], 12)
            mx, my = pygame.mouse.get_pos()
            current_pos = (mx, my)

            if not is_tracing and trace_points:
                start_dist = ((mx - trace_points[1][0])**2 + (my - trace_points[1][1])**2)**0.5
                if start_dist <= 20:
                    is_tracing = True
                    magic_timer_start = pygame.time.get_ticks() 
                    magic_timer_started = True
                    player_path.append(current_pos)
            elif is_tracing:
                if len(player_path) == 0 or player_path[-1] != current_pos:
                    player_path.append(current_pos)
                if len(player_path) > 10:
                    player_path.pop(0)
                if len(player_path) > 3:
                    collision_tripped = True
                    for i in range(len(trace_points) - 1):
                        p1 = trace_points[i]
                        p2 = trace_points[i+1]
                        dx, dy = p2[0] - p1[0], p2[1] - p1[1]
                        seg_len_sq = dx*dx + dy*dy
                        if seg_len_sq > 0:
                            t = max(0, min(1, ((mx - p1[0]) * dx + (my - p1[1]) * dy) / seg_len_sq))
                            closest_x = p1[0] + t * dx
                            closest_y = p1[1] + t * dy
                            mouse_to_track_dist = ((mx - closest_x)**2 + (my - closest_y)**2)**0.5
                            if mouse_to_track_dist <= 14:
                                collision_tripped = False
                                break
                    if collision_tripped:
                        battle_log = "Wand touched the barrier! Spell destabilized."
                        game_state = "playing"
                        turn_state = "enemy_waiting"
                        enemy_turn_start_time = pygame.time.get_ticks()
                        player_path = []
                        is_tracing = False
                        magic_timer_started = False
                        clicked = False

                    finish_dist = ((mx - trace_points[-2][0])**2 + (my - trace_points[-2][1])**2)**0.5
                    if finish_dist <= 15:
                        base_scaled_dmg = int(spell_damage * shop_bonus_damage * tree_bonus_damage * lucky_7_dmg_mult)
                        final_magic_dmg = base_scaled_dmg
                        if arc_overflow_lvl > 0 and mana >= max_mana:
                            if arc_overflow_lvl == 1: final_magic_dmg = int(final_magic_dmg * 1.1)
                            elif arc_overflow_lvl == 2: final_magic_dmg = int(final_magic_dmg * 1.2)
                            elif arc_overflow_lvl == 3: final_magic_dmg = int(final_magic_dmg * 1.3)
                        chan_focus_lvl = player_progression.get("p5_n4", 0)
                        if chan_focus_lvl == 3 and random.randint(1, 100) <= 15:
                            mana = min(max_mana, mana + 11)
                            battle_log = "FOCUS REFUND! Your spell cost 0 mana"
                        if arc_overflow_lvl > 0 and mana >= max_mana:
                            if arc_overflow_lvl == 1: final_magic_dmg = int(final_magic_dmg * 1.1)
                            elif arc_overflow_lvl == 2: final_magic_dmg = int(final_magic_dmg * 1.2)
                            elif arc_overflow_lvl == 3: final_magic_dmg = int(final_magic_dmg * 1.3)
                        enemy_hp = max(0, enemy_hp - final_magic_dmg)
                        if siph_arc_lvl > 0:
                            if siph_arc_lvl == 1: mana = min(max_mana, mana + int(final_magic_dmg * 0.15))
                            elif siph_arc_lvl == 2: mana = min(max_mana, mana + int(final_magic_dmg * 0.30))
                            elif siph_arc_lvl == 3: mana = min(max_mana, mana + int(final_magic_dmg * 0.45))
                        if enemy_hp <= 0:
                            enemy_state = "fade"
                            battle_log = "SPELL CAST SUCCESS! You completely disintegrated the orc"
                        else:
                            battle_log = f"Your incantation strikes the orc for {final_magic_dmg} magic damage"
                        game_state = "playing"
                        turn_state = "enemy_waiting"
                        enemy_turn_start_time = pygame.time.get_ticks()
                        player_path = []
                        is_tracing = False
                        magic_timer_started = False
                        clicked = False

            if len(player_path) >= 2:
                pygame.draw.lines(screen, (160, 100, 220), False, player_path, width=brush_size)
                for pt in player_path:
                    pygame.draw.circle(screen, (160, 100, 220), pt, brush_size // 2)
            if not magic_timer_started:
                clock_text = "Hover Green to Start"
            else:
                clock_text = f"Spell Fuse: {time_remaining/1000:.1f}s"
            screen.blit(game_font.render(clock_text, True, (240, 220, 150)), (330, 30))
            if magic_timer_started and time_remaining <= 0:
                battle_log = "The incantation collapsed! Spell fizzled."
                game_state = "playing"
                turn_state = "enemy_waiting"
                enemy_turn_start_time = pygame.time.get_ticks()
                player_path = []
                is_tracing = False
                magic_timer_started = False
                clicked = False

        elif game_state == "playing":
            screen.fill((22, 56, 50))
            open_Casino_lvl = player_progression.get("p6_n6", 0)

            if open_Casino_lvl >= 1:
                pygame.draw.rect(screen, (100, 30, 60), casino_btn)
                screen.blit(game_font.render("casino", True, (255, 255, 255)), (180, 42))
                if clicked and casino_btn.collidepoint(mouse_pos) and enemy_state == "battle" and turn_state == "player":
                    game_state = "casino"
                    clicked = False
                    pygame.event.clear(pygame.MOUSEBUTTONDOWN)
            lucky_7_dmg_mult = 1
            lucky_7_crit_bonus = 0
            if gold % 10 == 7 or gold % 10 == 3:
                lucky_7_lvl = player_progression.get("p6_n4", 0)
                if lucky_7_lvl == 1:
                    lucky_7_dmg_mult = 1.2
                    lucky_7_crit_bonus = 10
                elif lucky_7_lvl == 2:
                    lucky_7_dmg_mult = 1.4
                    lucky_7_crit_bonus = 10
                elif lucky_7_lvl == 3:
                    lucky_7_dmg_mult = 1.6
                    lucky_7_crit_bonus = 20

            pygame.draw.rect(screen, (80, 80, 90), shop_btn)
            screen.blit(game_font.render("shop", True, (255, 255, 255)), (72, 42))
            if clicked and shop_btn.collidepoint(mouse_pos) and enemy_state == "battle" and turn_state == "player":
                game_state = "shop"
                clicked = False
                pygame.event.clear(pygame.MOUSEBUTTONDOWN)

            if enemy_state == "march":
                if enemy_x > 605: enemy_x -= 0.4
                else: enemy_state = "battle"; turn_state = "player"; enemy_turn_start_time = pygame.time.get_ticks()

            elif enemy_state == "fade":
                if enemy_alpha > 0: enemy_alpha -= 0.6
                else:
                    bounce_coin_lvl = player_progression.get("p6_n1", 0)
                    merch_favor_lvl = player_progression.get("p4_n2", 0)
                    lucky_find_lvl = player_progression.get("p4_n3", 0)
                    comp_inter_lvl = player_progression.get("p4_n4", 0)
                    gold_mult_roll_2 = random.randint(1, 100)
                    gold_mult_roll_1 = random.randint(1, 100)
                    merch_favor_roll = random.randint(1, 100)
                    free_shop_roll = random.randint(1, 6)
                    if merch_favor_lvl == 1:
                        if merch_favor_roll <= 25:
                            if free_shop_roll == 1: hp_boost_price = 0
                            elif free_shop_roll == 2: full_heal_price = 0
                            elif free_shop_roll == 3: dmg_boost_price = 0
                            elif free_shop_roll == 4: potions_boost_price = 0
                            elif free_shop_roll == 5: bonus_crit_chance_price = 0
                            elif free_shop_roll == 6: gold_bonus_price = 0
                    if merch_favor_lvl == 2:
                        if merch_favor_roll <= 50:
                            if free_shop_roll == 1: hp_boost_price = 0
                            elif free_shop_roll == 2: full_heal_price = 0
                            elif free_shop_roll == 3: dmg_boost_price = 0
                            elif free_shop_roll == 4: potions_boost_price = 0
                            elif free_shop_roll == 5: bonus_crit_chance_price = 0
                            elif free_shop_roll == 6: gold_bonus_price = 0
                    if merch_favor_lvl == 3:
                        if merch_favor_roll <= 75:
                            if free_shop_roll == 1: hp_boost_price = 0
                            elif free_shop_roll == 2: full_heal_price = 0
                            elif free_shop_roll == 3: dmg_boost_price = 0
                            elif free_shop_roll == 4: potions_boost_price = 0
                            elif free_shop_roll == 5: bonus_crit_chance_price = 0
                            elif free_shop_roll == 6: gold_bonus_price = 0
                    if bounce_coin_lvl == 1 and gold_mult_roll_1 <= 10: tree_gold_mult_1 = 2
                    elif bounce_coin_lvl == 2 and gold_mult_roll_1 <= 20: tree_gold_mult_1 = 2
                    elif bounce_coin_lvl == 3 and gold_mult_roll_1 <= 20: tree_gold_mult_1 = 3
                    else: tree_gold_mult_1 = 1
                    if lucky_find_lvl == 1 and gold_mult_roll_2 <= 10: tree_gold_mult_2 = 2
                    elif lucky_find_lvl == 2 and gold_mult_roll_2 <= 20: tree_gold_mult_2 = 2
                    elif lucky_find_lvl <= 30 and gold_mult_roll_2 > 20: tree_gold_mult_2 = 2
                    else: tree_gold_mult_2 = 1
                    if comp_inter_lvl == 1: gold_interest = gold * 0.05
                    elif comp_inter_lvl == 2: gold_interest = gold * 0.1
                    elif comp_inter_lvl == 3: gold_interest = gold  * 0.15
                    gold += int(gold_interest)
                    gold += (random.randint(3, 7) * orc_number + bonus_gold) * tree_gold_mult_1 * tree_gold_mult_2
                    player_progression["xp"] += 7
                    save_game()
                    orc_number += 1
                    enemy_max_hp = 40 + (orc_number * 20)
                    if orc_number >= 8 and random.randint(1, 100) <= 35:
                        enemy_has_shield = True
                        battle_log = f"orc #{orc_number} is approaching with a reinforced heavy shield!"
                    else:
                        enemy_has_shield = False
                    enemy_hp = enemy_max_hp
                    enemy_attack_power = 2 + (orc_number * 3)
                    enemy_x = 850
                    enemy_alpha = 255
                    enemy_state = "march"

            if game_state == "playing" and clicked and enemy_state == "battle" and turn_state == "player":
                if attack_btn.collidepoint(mouse_pos):
                    tree_heal_bonus_stack = 0
                    gold_scale_lvl = player_progression.get("p4_n5", 0)
                    gold_scale_mult = 1
                    if gold_scale_lvl > 0 and gold > 0:
                        gold_chunks = gold // 20
                        if gold_scale_lvl == 1:
                            bonus_pct = gold_chunks * 0.02
                        elif gold_scale_lvl == 2:
                            bonus_pct = gold_chunks * 0.04
                        elif gold_scale_lvl == 3:
                            bonus_pct = gold_chunks * 0.06
                        if bonus_pct > 0.5:
                            bonus_pct = 0.5
                        gold_scale_mult += bonus_pct
                    dmg = int(random.randint(7, 12) * shop_bonus_damage * lucky_7_dmg_mult * tree_bonus_damage * tree_heal_dmg_bonus * gold_scale_mult)
                    if enemy_has_shield:
                        dmg = int(dmg * 0.6)
                    high_roller_lvl = player_progression.get("p6_n2", 0)
                    concussive_lvl = player_progression.get("p2_n3", 0)
                    vamp_blade_lvl = player_progression.get("p2_n5", 0)
                    guillotine_lvl = player_progression.get("p2_n6", 0)
                    midas_touch_lvl = player_progression.get("p4_n6", 0)
                    luck_roll = random.randint(1, 100)
                    stun_roll = random.randint(1, 100)
                    triggered_luck = False
                    triggered_guillotine = False
                    gold_convert = 0
                    if midas_touch_lvl > 0:
                        if midas_touch_lvl == 1:
                            gold_convert = dmg * 0.05
                        elif midas_touch_lvl == 2:
                            gold_convert = dmg * 0.1
                        elif midas_touch_lvl == 3:
                            gold_convert = dmg * 0.15
                    if concussive_lvl == 1 and stun_roll <= 5:
                        enemy_stunned = True
                    elif concussive_lvl == 2 and stun_roll <= 10:
                        enemy_stunned = True
                    elif concussive_lvl == 3 and stun_roll <= 15:
                        enemy_stunned = True
                    if high_roller_lvl == 1 and luck_roll <= 10:
                        dmg = int(dmg * 1.5)
                        triggered_luck = True
                    elif high_roller_lvl == 2 and luck_roll <= 20:
                        dmg = int(dmg * 1.5)
                        triggered_luck = True
                    elif high_roller_lvl == 3 and luck_roll <= 20:
                        dmg = int(dmg * 2)
                        triggered_luck = True
                    if vamp_blade_lvl == 1:
                        dmg_heal = int(dmg * 0.15)
                    elif vamp_blade_lvl == 2:
                        dmg_heal = int(dmg * 0.2)
                    elif vamp_blade_lvl == 3:
                        dmg_heal = int(dmg * 0.25)
                    else:
                        dmg_heal = 0
                    if vamp_blade_lvl != 0 and dmg_heal < 1:
                        dmg_heal = 1
                    player_hp = min(player_max_hp, player_hp + dmg_heal)
                    if guillotine_lvl == 1:
                        if enemy_hp <= enemy_max_hp * 0.06:
                            enemy_hp = 0
                            triggered_guillotine = True
                    elif guillotine_lvl == 2:
                        if enemy_hp <= enemy_max_hp * 0.12:
                            enemy_hp = 0
                            triggered_guillotine = True
                    elif guillotine_lvl == 3:   
                        if enemy_hp <= enemy_max_hp * 0.2:
                            enemy_hp = 0
                            triggered_guillotine = True
                    if triggered_guillotine:
                        enemy_state = "fade"
                        last_damage_dealt = dmg
                    else:
                        enemy_hp -= dmg
                        last_damage_dealt = dmg
                        if enemy_hp <= 0:
                            enemy_hp = 0
                            enemy_state = "fade"
                        else:
                            turn_state = "enemy_waiting"
                            enemy_turn_start_time = pygame.time.get_ticks()
                    if triggered_guillotine:
                        battle_log = "GUILLOTINE! Off with their head"
                    elif enemy_hp == 0:
                        battle_log = "you've slayed the orc"
                    elif triggered_luck:
                        battle_log = f"LUCKY STRIKE! you slash the orc for {dmg} damage"
                    else:
                        battle_log = f"You slashed the orc for {dmg} damage"
                    tree_heal_dmg_bonus = 1
                    gold += int(gold_convert)

                elif heavy_btn.collidepoint(mouse_pos):
                    tree_heal_bonus_stack = 0
                    gold_scale_lvl = player_progression.get("p4_n5", 0)
                    gold_scale_mult = 1
                    if gold_scale_lvl > 0 and gold > 0:
                        gold_chunks = gold // 20
                        if gold_scale_lvl == 1:
                            bonus_pct = gold_chunks * 0.02
                        elif gold_scale_lvl == 2:
                            bonus_pct = gold_chunks * 0.04
                        elif gold_scale_lvl == 3:
                            bonus_pct = gold_chunks * 0.06
                        if bonus_pct > 0.5:
                            bonus_pct = 0.5
                    if random.randint(1, 100) <= 50 + shop_bonus_crit_chance + lucky_7_crit_bonus + tree_bonus_crit_chance:
                        dmg = int(random.randint(14, 24) * shop_bonus_damage * lucky_7_dmg_mult * tree_bonus_damage * tree_heal_dmg_bonus * gold_scale_mult)
                        if enemy_has_shield:
                            dmg = int(dmg * 0.6)
                        high_roller_lvl = player_progression.get("p6_n2", 0)
                        concussive_lvl = player_progression.get("p2_n3", 0)
                        vamp_blade_lvl = player_progression.get("p2_n5", 0)
                        guillotine_lvl = player_progression.get("p2_n6", 0)
                        midas_touch_lvl = player_progression.get("p4_n6", 0)
                        luck_roll = random.randint(1, 100)
                        stun_roll = random.randint(1, 100)
                        triggered_luck = False
                        triggered_guillotine = False
                        gold_convert = 0
                        if midas_touch_lvl > 0:
                            if midas_touch_lvl == 1:
                                gold_convert = dmg * 0.05
                            elif midas_touch_lvl == 2:
                                gold_convert = dmg * 0.1
                            elif midas_touch_lvl == 3:
                                gold_convert = dmg * 0.15
                            gold_scale_mult += bonus_pct
                        if concussive_lvl == 1 and stun_roll <= 5:
                            enemy_stunned = True
                        elif concussive_lvl == 2 and stun_roll <= 10:
                            enemy_stunned = True
                        elif concussive_lvl == 3 and stun_roll <= 15:
                            enemy_stunned = True
                        if high_roller_lvl == 1 and luck_roll <= 10:
                            dmg = int(dmg * 1.5)
                            triggered_luck = True
                        elif high_roller_lvl == 2 and luck_roll <= 20:
                            dmg = int(dmg * 1.5)
                            triggered_luck = True
                        elif high_roller_lvl == 3 and luck_roll <= 20:
                            dmg = int(dmg * 2)
                            triggered_luck = True
                        if vamp_blade_lvl == 1:
                            dmg_heal = int(dmg * 0.15)
                        elif vamp_blade_lvl == 2:
                            dmg_heal = int(dmg * 0.2)
                        elif vamp_blade_lvl == 3:
                            dmg_heal = int(dmg * 0.25)
                        else:
                            dmg_heal = 0
                        if vamp_blade_lvl != 0 and dmg_heal < 1:
                            dmg_heal = 1
                        player_hp = min(player_max_hp, player_hp + dmg_heal)
                        if guillotine_lvl == 1:
                            if enemy_hp <= enemy_max_hp * 0.06:
                                enemy_hp = 0
                                triggered_guillotine = True
                        elif guillotine_lvl == 2:
                            if enemy_hp <= enemy_max_hp * 0.12:
                                enemy_hp = 0
                                triggered_guillotine = True
                        elif guillotine_lvl == 3:   
                            if enemy_hp <= enemy_max_hp * 0.2:
                                enemy_hp = 0
                                triggered_guillotine = True
                        if triggered_guillotine:
                            enemy_state = "fade"
                            last_damage_dealt = dmg
                        else:
                            enemy_hp -= dmg
                            last_damage_dealt = dmg
                            if enemy_hp <= 0:
                                enemy_hp = 0
                                enemy_state = "fade"
                            else:
                                turn_state = "enemy_waiting"
                                enemy_turn_start_time = pygame.time.get_ticks()
                        if triggered_guillotine:
                            battle_log = "GUILLOTINE! Off with their head"
                        elif triggered_luck:
                            battle_log = f"JACKPOT CRIT! you pierce the orc for {dmg} damage"
                        elif enemy_hp == 0:
                            battle_log = "you've slayed the orc"
                        else:
                            battle_log = f"CRITICAL HIT! you pierce the orc for {dmg} damage"
                    else:
                        battle_log = f"your attack attempt missed"
                        turn_state = "enemy_waiting"
                        enemy_turn_start_time = pygame.time.get_ticks()
                    tree_heal_dmg_bonus = 1
                    gold += int(gold_convert)

                elif heal_btn.collidepoint(mouse_pos):
                    sooth_vapor_lvl = player_progression.get("p3_n1", 0)
                    adren_rush_lvl = player_progression.get("p3_n2", 0)
                    corr_splash_lvl = player_progression.get("p3_n6", 0)
                    if corr_splash_lvl == 1:
                        healing_dmg = 0.15
                    elif corr_splash_lvl == 2:
                        healing_dmg = 0.25
                    elif corr_splash_lvl == 3:
                        healing_dmg = 0.35
                    else:
                        healing_dmg = 0
                    if tree_heal_bonus_stack == tree_heal_bonus_stack_max:
                        tree_heal_bonus_stack -= 1
                    if not adren_rush_lvl == 0:
                        tree_heal_dmg_bonus = 1
                        if adren_rush_lvl == 1:
                            tree_heal_bonus_stack_max = 1
                            if tree_heal_bonus_stack < tree_heal_bonus_stack_max:
                                tree_heal_dmg_bonus += 0.1
                                tree_heal_bonus_stack += 1
                        elif adren_rush_lvl == 2:
                            tree_heal_bonus_stack_max = 1
                            if tree_heal_bonus_stack < tree_heal_bonus_stack_max:
                                tree_heal_dmg_bonus += 0.2
                                tree_heal_bonus_stack += 1
                        elif adren_rush_lvl == 3:
                            tree_heal_bonus_stack_max = 2
                            if tree_heal_bonus_stack < tree_heal_bonus_stack_max:
                                tree_heal_dmg_bonus += 0.2
                                tree_heal_bonus_stack += 1
                    if sooth_vapor_lvl == 1:
                        min_heal = 12
                        max_heal = 27
                    elif sooth_vapor_lvl == 2:
                        min_heal = 17
                        max_heal = 32
                    elif sooth_vapor_lvl == 3:
                        min_heal = 22
                        max_heal = 37
                    else:
                        min_heal = 7
                        max_heal = 22
                    raw_roll = int(random.randint(min_heal, max_heal) * bonus_heal)
                    old = player_hp
                    overheal_lvl = player_progression.get("p3_n4", 0)
                    overheal_bonus = 0
                    if player_hp > player_max_hp:
                        battle_log = "your health is already overhealed"
                    else:
                        if player_hp + raw_roll > player_max_hp:
                            hp_needed = player_max_hp - player_hp
                            wasted_overflow = raw_roll - hp_needed
                            if player_hp <= player_max_hp and overheal_lvl > 0:
                                if overheal_lvl == 1:
                                    overheal_bonus = int(wasted_overflow * 0.6)
                                elif overheal_lvl == 2:
                                    overheal_bonus = int(wasted_overflow * 0.75)
                                elif overheal_lvl == 3:
                                    overheal_bonus = wasted_overflow
                            player_hp = player_max_hp + overheal_bonus
                        else:
                            player_hp += raw_roll
                        last_heal_amount = player_hp - old
                        battle_log = f"you drink a potion and heal {last_heal_amount} health"
                        healing_dmg_done = int(last_heal_amount * healing_dmg)
                        enemy_hp -= healing_dmg_done
                    turn_state = "enemy_waiting"
                    enemy_turn_start_time = pygame.time.get_ticks()

            if game_state == "playing" and turn_state == "enemy_waiting" and pygame.time.get_ticks() - enemy_turn_start_time > 1100:
                if enemy_stunned == True:
                    battle_log = "the orc is stunned and skipped it's turn"
                    turn_state = "player"
                    enemy_stunned = False
                else:
                    Iron_Ward_lvl = player_progression.get("p1_n3", 0)
                    spike_armour_lvl = player_progression.get("p1_n5")
                    if Iron_Ward_lvl == 1:
                        hp_shield = 0.9
                    elif Iron_Ward_lvl == 2:
                        hp_shield = 0.8
                    elif Iron_Ward_lvl == 3:
                        hp_shield = 0.7
                    else:
                        hp_shield = 1
                    if spike_armour_lvl == 1:
                        spike_shield = 0.1
                    elif spike_armour_lvl == 2:
                        spike_shield = 0.2
                    elif spike_armour_lvl == 3:
                        spike_shield = 0.3
                    else:
                        spike_shield = 0
                    enemy_base_damage = enemy_attack_power + random.randint(-(orc_number * 2), (orc_number * 2))
                    enemy_damage_done = max(1, int(enemy_base_damage * hp_shield))
                    player_hp -= enemy_damage_done
                    spike_shield_dmg = int(enemy_base_damage * spike_shield)
                    if spike_armour_lvl != 0 and spike_shield_dmg < 1:
                        spike_shield_dmg = 1
                    enemy_hp -= spike_shield_dmg
                    battle_log = f"the orc did {enemy_damage_done} damage to you"
                    turn_state = "player"

                hp_boost_price = 15
                dmg_boost_price = 15
                full_heal_price = 5
                potions_boost_price = 15
                leyline_flow_lvl = player_progression.get("p5_n3", 0)
                if leyline_flow_lvl == 1:
                    mana_regen = 6
                elif leyline_flow_lvl >= 2:
                    mana_regen = 7
                else:
                    mana_regen = 5
                mana = min(max_mana, mana + mana_regen)
                bonus_crit_chance_price = 15
                gold_bonus_price = 15

            if game_state == "playing" and player_hp < 1:
                sec_wind_lvl = player_progression.get("p1_n4", 0)
                if sec_wind_left > 0:
                    if sec_wind_lvl == 1:
                        player_hp = 40
                        sec_wind_left -= 1
                    elif sec_wind_lvl == 2 or sec_wind_lvl == 3:
                        player_hp = 40 + int(player_max_hp * 0.3)
                        sec_wind_left -= 1
                else:
                    game_state = "title"

            pygame.draw.rect(screen, (123, 123, 123), (100, 535, 100, 100))
            enemy_surface.fill((0, 0, 0, 0))
            pygame.draw.rect(enemy_surface, (156, 87, 22, enemy_alpha), (0, 0, 100, 100))
            screen.blit(enemy_surface, (enemy_x, enemy_y))

            pygame.draw.rect(screen, (180, 180, 180), attack_btn)
            pygame.draw.rect(screen, (180, 180, 180), heavy_btn)
            pygame.draw.rect(screen, (180, 180, 180), heal_btn)

            myst_chan_lvl = player_progression.get("p5_n1", 0)
            chan_focus_lvl = player_progression.get("p5_n4", 0)
            leyline_flow_lvl = player_progression.get("p5_n3", 0)
            arcane_pres_lvl = player_progression.get("p5_n2", 0)
            if myst_chan_lvl > 0:
                pygame.draw.rect(screen, (180, 180, 180), magic_btn)
                screen.blit(game_font.render("magic attack", True, (255, 255, 255)), (605, 622))

                if clicked and magic_btn.collidepoint(mouse_pos) and enemy_state == "battle" and turn_state == "player":
                    spell_cost = 15
                    if chan_focus_lvl == 1: spell_cost = 13
                    elif chan_focus_lvl == 2: spell_cost = 11
                    elif chan_focus_lvl == 3: spell_cost = 11
                    can_cast = False
                    use_hp_sacrifice = False
                    hp_lost = 0
                    if mana >= spell_cost:
                        can_cast = True
                    elif leyline_flow_lvl == 3:
                        missing_mana = spell_cost - mana
                        hp_lost = missing_mana * 2
                        if player_hp > hp_lost:
                            can_cast = True
                            use_hp_sacrifice = True

                    if can_cast:
                        if use_hp_sacrifice:
                            mana = 0
                            player_hp -= hp_lost
                        else:
                            if not (chan_focus_lvl == 3 and random.randint(1, 100) <= 15):
                                mana -= spell_cost
                        if arcane_pres_lvl == 3:
                            scaled_magic_dmg = int(spell_damage * shop_bonus_damage * tree_bonus_damage * lucky_7_dmg_mult)
                            enemy_hp = max(0, enemy_hp - scaled_magic_dmg)
                            if enemy_hp <= 0:
                                enemy_state = "fade"
                                battle_log = "SPELL CAST SUCCESS! You completely disintegrated the orc!"
                            else:
                                battle_log = f"Instant Cast! Your spell deals {scaled_magic_dmg} magic damage!"
                            turn_state = "enemy_waiting"
                            enemy_turn_start_time = pygame.time.get_ticks()
                        else:
                            game_state = "magic_minigame"
                            magic_timer_start = 0
                            magic_timer_started = False
                            is_tracing = False
                            player_path = []
                            trace_points = [(180, 420), (200, 400), (350, 250), (500, 550), (650, 400), (670, 380)]
                    else:
                        battle_log = "Not enough mana to shape a spell"
                    clicked = False

            screen.blit(game_font.render("attack", True, (255, 255, 255)), (125, 722))
            screen.blit(game_font.render("heavy attack", True, (255, 255, 255)), (355, 722))
            screen.blit(game_font.render("heal", True, (255, 255, 255)), (635, 722))
            screen.blit(game_font.render(f"player hp: {player_hp}/{player_max_hp}", True, (230, 90, 90)), (85, 650))
            screen.blit(log_font.render(f"gold: {gold}", True, (255, 215, 0)), (50, 90))
            screen.blit(game_font.render(f"orc #{orc_number} hp: {enemy_hp}/{enemy_max_hp}", True, (230, 90, 90)), (600, 50))
            if myst_chan_lvl > 0:
                screen.blit(log_font.render(f"mana: {mana}/{max_mana}", True, (70, 140, 240)), (50, 130))
            if enemy_has_shield:
                screen.blit(game_font.render("(SHIELDED - 40% PHYS RESIST)", True, (180, 180, 190)), (540, 20))

            if battle_log == f"an angry orc blocks your path":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (220, 350))
            elif battle_log == f"orc #{orc_number} is approaching":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (260, 350))
            elif battle_log == f"orc #{orc_number} is ready to fight":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (260, 350))
            elif battle_log == f"You slashed the orc for {last_damage_dealt} damage":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (200, 350))
            elif battle_log == f"CRITICAL HIT! you pierce the orc for {last_damage_dealt} damage":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (110, 350))
            elif battle_log == f"your attack attempt missed":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (240, 350))
            elif battle_log == f"you drink a potion and heal {last_heal_amount} health":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (200, 350))
            elif battle_log == f"the orc did {enemy_damage_done} damage to you":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (240, 350))
            elif battle_log == f"LUCKY STRIKE! you slash the orc for {dmg} damage":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (120, 350))
            elif battle_log == f"JACKPOT CRIT! you pierce the orc for {dmg} damage":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (110, 350))
            elif battle_log == "the orc is stunned and skipped it's turn":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (160, 350))
            elif battle_log == "GUILLOTINE! Off with their head":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (210, 350))
            elif battle_log == "you've slayed the orc":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (270, 350))
            elif battle_log == "your health is already overhealed":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (200, 350))
            elif battle_log == "Not enough mana to shape a spell!":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (210, 350))
            elif battle_log == "The incantation collapsed! Spell fizzled.":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (180, 350))
            elif battle_log == "Wand touched the barrier! Spell destabilized.":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (140, 350))
            elif battle_log == "FOCUS REFUND! Your spell cost 0 mana":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (210, 350))
            elif battle_log == "SPELL CAST SUCCESS! You completely disintegrated the orc":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (140, 350))
            elif battle_log == f"Your incantation strikes the orc for {spell_damage} magic damage":
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (160, 350))
            elif "magic damage" in battle_log:
                screen.blit(log_font.render(battle_log, True, (240, 240, 240)), (160, 350))

        pygame.display.flip()
        await asyncio.sleep(0)
asyncio.run(start_web_game())